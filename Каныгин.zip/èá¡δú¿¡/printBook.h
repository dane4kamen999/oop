#ifndef LAB1_PRINT_BOOK_H
#define LAB1_PRINT_BOOK_H

#include <iostream>
#include <string.h>
#include "book.h"



class PrintBook : public Book {
    private:
		int printPages;
		
    public:

        PrintBook(std::string title, std::string author, int pages) : Book(title, author, pages)
        {
            printPages = pages/16;
        }

        int getPages(){
            return printPages;
        }
};

#endif
