#include "book.h"



Book::Book(std::string title, std::string author, unsigned int pages) : title(title),
                                                                        mark(0),
                                                                        author(author) {
    this->pages = pages;
}



unsigned int Book::getPages() {
    return pages;
}

unsigned int Book::getMark() {
    return mark;
}

std::string Book::getAuthor() {
    return author;
}

std::string Book::getTitle() {
    return title;
}

void Book::setMark(unsigned int mark) {
    if (mark <= this->pages) {
        this->mark = mark;
    } else std::cout << "wroong bookmaark\n";
}



void Book::setTitle(std::string title) {
    this->title = title;
}

void Book::setAuthor(std::string author) {
    this->author = author;
}

void Book::setPages(unsigned int pages) {
    this->pages = pages;
}

void Book::writeBook() {
    std::cout << getTitle() << ",   " << getAuthor() << ",   " << getPages() << std::endl;
}

Book::~Book() {}





