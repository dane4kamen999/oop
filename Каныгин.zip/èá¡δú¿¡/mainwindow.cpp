#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <string>
using namespace std;
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_addBookShelf_clicked() //что делает программа на кнопку добавления шкафа
{
   int id = bookShelfs.size()+1;
   ui->listWidget_BookShelfs->addItem(QString::number(id));
   Bookshelf bs = Bookshelf(10);
   bookShelfs.push_back(bs);
}
void MainWindow::on_pushButtondelBookShelf_clicked() //что делает программа на кнопку удаления шкафа
{
   int id = bookShelfs.size()-1;
   ui->listWidget_BookShelfs->addItem(QString::number(id));
   Bookshelf bs = Bookshelf(10);
   bookShelfs.push_back(bs);
}

void MainWindow::on_pushButton_addShelf_clicked()//что делает программа на кнопку добавления полки
{
    int id = Shelfs.size()+1;
    ui->listWidget_Shelfs->addItem(QString::number(id));
    Shelf bs = Shelf(20);
    Shelfs.push_back(bs);
}
void MainWindow::on_pushButtondelShelf_clicked()//что делает программа на кнопку удаления полки
    {
    int id = Shelfs.size()-1;
    ui->listWidget_Shelfs->addItem(QString::number(id));
    Shelf bs = Shelf(20);
    Shelfs.push_back(bs);
}
void MainWindow::on_pushButton_addBook_clicked(){//что делает программа на кнопку добавления книги(скорее всего не правильно сделан вывод)
    QString Author=ui->label->text();
    QString Title=ui->label_2->text();
    QString Pages=ui->spinBox->text();
    int id = Shelfs.size()+1;
    ui->listWidget_book->addItem(QString::number(id));
}
void MainWindow::on_pushButton_delBook_clicked(){//что делает программа на кнопку удаления книги(скорее всего не правильно сделан вывод)
    QString Author=ui->label->text();
    QString Title=ui->label_2->text();
    QString Pages=ui->spinBox->text();
    int id = Shelfs.size()-1;
    ui->listWidget_book->addItem(QString::number(id));
}
