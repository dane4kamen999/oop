#ifndef LAB1_BOOK_H
#define LAB1_BOOK_H

#include <iostream>


class Book {
    std::string title;
    std::string author;
    unsigned int pages;
    unsigned int mark;

public:

    Book(std::string title, std::string author, unsigned int pages);
    Book() : pages(0), mark(0) {};
    unsigned int getPages();
    unsigned int getMark();
    std::string getTitle();
    std::string getAuthor();

    void setMark(unsigned int mark);
    void setTitle(std::string title);
    void setAuthor(std::string author);
    void setPages(unsigned int pages);
    void writeBook();


    ~Book();


};

#endif


