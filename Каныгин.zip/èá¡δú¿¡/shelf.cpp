#include "shelf.h"




Shelf::Shelf(unsigned int shelf_size) : shelf_size(shelf_size) {}


void Shelf::setSize(unsigned int size) {
    this->shelf_size = size;
}


void Shelf::addBook(PrintBook new_book) {
    if (books_list.size() < this->shelf_size) {
        this->books_list.push_back(new_book);
    } else std::cout << "На полке нет места для новой книги\n";
}



void Shelf::writeShelf() {
    for (PrintBook wbook : books_list) {
        wbook.writeBook();
    }
}


unsigned int Shelf::getSize() {
    return this->books_list.size();
}


unsigned int Shelf::capacitySize() {
    return this->shelf_size;
}


bool Shelf::findBook(std::string title, std::string author) {
    for (PrintBook booki : books_list) {
        if ((title == booki.getTitle()) &&
            (author == booki.getAuthor())){
              return true;
        }
    }
    return false;
}



int Shelf::getPlace(std::string title, std::string author) {
    for (int i = 0; i < books_list.size(); i++) {
        if ((title == books_list[i].getTitle()) &&
            (author == books_list[i].getAuthor())) {
            return i;
        }
        return -1;
    }
    return 0;
}


void Shelf::putBook(PrintBook afterbook, PrintBook putbook) {
    if (this->shelf_size == this->books_list.size()) {
        std::cout << "На полке нет места для новой книги\n";
        return;
    }
    int place = this->getPlace(afterbook.getTitle(), afterbook.getAuthor());

    if (place == -1) {
        this->books_list.push_back(putbook);
    } else {
        this->books_list.insert(books_list.begin() + place + 1, putbook);

    }
}


void Shelf::removeBook(std::string title, std::string author) {
    if (this->findBook(title, author)) {
        books_list.erase(books_list.begin() + this->getPlace(title, author));


    }

}


void Shelf::removeBook(unsigned int place) {
    if (place < books_list.size())
        books_list.erase(books_list.begin() + place);

}


//////////////////////////////// Здесь находятся методы с исключениями /////////////////////////////////////////////////

PrintBook & Shelf::getBook(std::string title, std::string author) {
    for (PrintBook & booki : books_list) {
        if ((title == booki.getTitle()) &&
            (author == booki.getAuthor())){
            return booki;
        }
    }
    throw std::domain_error("Книга с названием " + title + " и автором " + author + " не найдена\n");
}



PrintBook & Shelf::getBook(unsigned int place) {
    if (place < books_list.size()){
        return books_list[place];
    }
    throw std::domain_error("Нет такого места на полке");

}




Shelf::~Shelf() {}

