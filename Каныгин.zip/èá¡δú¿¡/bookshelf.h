#ifndef LAB1_BOOKSHELF_H
#define LAB1_BOOKSHELF_H
#include "shelf.h"
#include <vector>



    class Bookshelf {
        std::vector<Shelf> shelves;
    public:
        explicit Bookshelf(unsigned  int size);

        bool findBook(std::string title, std::string author);
        unsigned int findShelf(std::string title, std::string author);

        void writeAddress(std::string title, std::string author);

        void addBook(unsigned int shelf_number, PrintBook abook);
        void putBook(unsigned int shelf_number, PrintBook afterbook, PrintBook putbook);
        void writeAll();
        void writeNumber();
        void writeShelf(unsigned int number);
        void removeBook(std::string title, std::string author);
        void removeBook(unsigned int shelf_number, unsigned int place);

        PrintBook & getBook(std::string title, std::string author);
        PrintBook & getBook(unsigned int place, unsigned int shelf_number);

        unsigned int getSize();
        void writeSize();


        ~Bookshelf();
    };

#endif
