#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "book.h"
#include "printBook.h"
#include "shelf.h"
#include "bookshelf.h"
#include <vector>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
// объявляю все кнопки, виджеты, спинбокс
    void on_pushButton_addBookShelf_clicked();
    void on_listWidget_Shelfs_currentItemChanged();
    void on_pushButton_addShelf_clicked();
    void on_pushButtondelShelf_clicked();
    void on_pushButtondelBookShelf_clicked();
    void on_pushButton_addBook_clicked();
    void on_pushButton_delBook_clicked();
    void on_spinBox_clicked();
    void on_listWidget_book_currentItemChanged();
private:
    Ui::MainWindow *ui;
    std::vector<Book> books;
    std::vector<Bookshelf> bookShelfs;
    std::vector<Shelf> Shelfs;
};
#endif // MAINWINDOW_H
