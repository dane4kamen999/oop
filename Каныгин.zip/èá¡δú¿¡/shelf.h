#ifndef LAB1_SHELF_H
#define LAB1_SHELF_H

#include <vector>
#include "printBook.h"

#define DEFAULT_SIZE 20



class Shelf {
    unsigned int shelf_size;
    std::vector<PrintBook> books_list;



public:


    explicit Shelf(unsigned int shelf_size = DEFAULT_SIZE);

    unsigned int capacitySize();
    unsigned int getSize();

    bool findBook(std::string title, std::string author);

    int getPlace(std::string title, std::string author);

    PrintBook & getBook(std::string title, std::string author);
    PrintBook & getBook(unsigned int place);

    void setSize(unsigned int size);
    void addBook(PrintBook abook);
    void putBook(PrintBook afterbook, PrintBook putbook);
    void removeBook(std::string title, std::string author);
    void removeBook(unsigned int place);
    void writeShelf();

    ~Shelf();

};

#endif
